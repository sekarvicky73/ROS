#! /usr/bin/env python

import rospy

rospy.init_node('node_one')
print "this is first node"