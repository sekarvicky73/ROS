# linux_for_ros
#this file structure is useful for file navigation through ubuntu terminal
