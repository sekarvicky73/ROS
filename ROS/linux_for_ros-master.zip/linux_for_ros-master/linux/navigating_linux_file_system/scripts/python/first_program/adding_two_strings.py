a = 'linux for robotics'
b = 'practicing the file system'

c = a + b
print(c)
