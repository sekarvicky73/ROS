print ('program_executed')
