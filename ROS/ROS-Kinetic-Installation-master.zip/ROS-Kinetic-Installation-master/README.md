# ROS-Kinetic-Installation
These are the steps used for ROS kinetic kame installation to build ROS application


# Setup your sources.list

sudo sh -c 'echo "deb http://packages.ros.org/ros/ubuntu $(lsb_release -sc) main" > /etc/apt/sources.list.d/ros-latest.list'

# Set up your keys

sudo apt-key adv --keyserver 'hkp://keyserver.ubuntu.com:80' --recv-key C1CF6E31E6BADE8868B172B4F42ED6FBAB17C654

# Installation

sudo apt-get update

# Desktop-Full Install: ROS, rqt, rviz, robot-generic libraries, 2D/3D simulators, navigation and 2D/3D perception

sudo apt-get install ros-kinetic-desktop-full

# To find available packages, use:

apt-cache search ros-kinetic

# Initialize rosdep

sudo rosdep init

rosdep update

# Environment setup

echo "source /opt/ros/kinetic/setup.bash" >> ~/.bashrc

source ~/.bashrc

source /opt/ros/kinetic/setup.bash

# Dependencies for building packages

sudo apt install python-rosinstall python-rosinstall-generator python-wstool build-essential
